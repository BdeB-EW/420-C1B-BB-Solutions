using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
 * Petite programme qui affiche un message.
 * 
 * Auteurs: Enseignants de 420-C1B-BB
 */
public class AfficherMessage : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Ceci est mon premier programme et j'en suis tr�s fier.");     
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
