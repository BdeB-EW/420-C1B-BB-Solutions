using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
 * D�monstration de Hello World pour Unity
 * 
 * Auteurs: Enseignants de 420-C1B-BB
 */

public class HelloWorld : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Hello World !!");
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
